const productImage = document.getElementById("product-image");

productImage.addEventListener("click", function() {
  // Benachrichtigung anzeigen
  alert("Das Bild wurde angeklickt!");
});
